#ifndef H_SEARCH_SERVER
#define H_SEARCH_SERVER

#include <istream>
#include <ostream>
#include <set>
#include <list>
#include <vector>
#include <map>
#include <string>
#include <mutex>

using namespace std;

const size_t WORDS_COUNT = 1000u;
const size_t DOCUMENT_COUNT = 50'000u;
const size_t WORD_LENGTH = 100u;
const size_t CORES_COUNT = 4u;
const size_t DOCUMENT_PER_WORD = 4000u;

vector<string_view> SplitIntoWords(string_view line);
int FindInsertionIndex(
  const array<pair<size_t, size_t>, 5>& t_arr, size_t count, size_t id);

template <typename K, typename V>
class ConcurrentMap {
public:

  struct Access {
    lock_guard<mutex> ref_guard;
    V& ref_to_value;
  };

  explicit ConcurrentMap(size_t bucket_count)
    : _pmap(bucket_count)
    {
    }

  Access operator[](const K& key) {
    auto idx = whichBucket(key);
    auto& map_part = _pmap[idx];
    return {lock_guard<mutex>(map_part.mtx), map_part.data[key]};
  }

  pair<bool, typename map<K, V>::const_iterator>
  Find(const K& key) const {
    auto r_it = _pmap.back().data.end();
    bool r = false;
    for (const auto& [mtx, data, update] : _pmap) {
      if (const auto it = data.find(key); it != data.end()) {
        r = true;
        r_it = it;
      }
    }
    return make_pair(r, r_it);
  }

  map<K, V> BuildOrdinaryMap() {
    map<K, V> r;
    for (auto& bucket : _pmap) {
      lock_guard part_guard(bucket.mtx);
      r.merge(bucket.data);
    } 
    return r;
  }
private:
  struct Bucket {
    mutex mtx;
    map<K, V> data;
    bool is_updated = false;
  };
  vector<Bucket> _pmap;
  size_t whichBucket(const K& key) {
    return _pmap.size() * key.size() / WORD_LENGTH;
  }
};


class InvertedIndex {
public:
  InvertedIndex()
  {
    _docs.reserve(DOCUMENT_COUNT);
  }
  void Add(string document);
  using MapIt = map<string_view, vector<pair<size_t, size_t>> >::const_iterator;
  pair<bool, MapIt>
  Lookup(string_view word);
  size_t GetDocumentCount() const {
    return _docs.size();
  }

  const string& GetDocument(size_t id) const {
    return _docs[id];
  }

private:
  map<string_view, vector<pair<size_t, size_t>> > _stats;
  vector<string> _docs;
};

class SearchServer {
public:
  SearchServer() = default;
  explicit SearchServer(istream& document_input);
  void UpdateDocumentBase(istream& document_input);
  void AddQueriesStream(istream& query_input, ostream& search_results_output);

private:
  InvertedIndex _index;
};

#endif /*H_SEARCH_SERVER*/